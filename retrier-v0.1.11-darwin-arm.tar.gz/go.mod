module github.com/homebrew-retrier

go 1.24.2

require github.com/creack/pty v1.1.24 // indirect
